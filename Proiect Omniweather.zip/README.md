# Proiect_Kotlin_PDM
## Tema Proiect:
__TBD__

## Date despre autori

### Program Master/An/Grupa
- Informatică Economică
- An 1
- Gr. 1115

### Autori/Studenti:
- VASILCANU Marius Daniel
- PĂDUCEL Alexandru-Gabriel
- OANĂ Andreea Ramona
- STAN Adrian Gabriel
